import os
import numpy as np
from collections import Counter

# Caminho base das pastas no seu computador
base_path = r'C:\Users\USER\smartdrive-net\data\embeddings'  # o prefixo "r" evita problemas com barras invertidas

# Lista das pastas numeradas de 1 a 7
folders = [f'clip_embeddingsA1_{i}' for i in range(1, 8)]

# Dicionário para armazenar as contagens por pasta
labels_count_by_folder = {}

for folder in folders:
    folder_path = os.path.join(base_path, folder)
    label_counter = Counter()

    for file in os.listdir(folder_path):
        if file.endswith('.npz'):
            try:
                file_path = os.path.join(folder_path, file)
                data = np.load(file_path)
                labels = data['labels']
                label_counter.update(labels.tolist())
            except Exception as e:
                print(f"Erro ao ler {file_path}: {e}")

    labels_count_by_folder[folder] = dict(label_counter)

# Exibir os resultados
for folder, counts in labels_count_by_folder.items():
    print(f'\nContagem de labels na pasta {folder}:')
    for label, count in sorted(counts.items()):
        print(f'  Classe {label}: {count}')
