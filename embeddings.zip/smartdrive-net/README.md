# smartdrive-net

This repository contains an extended implementation of SRLF-Net with temporal modeling and uncertainty estimation for driver activity recognition.

See full documentation soon.
